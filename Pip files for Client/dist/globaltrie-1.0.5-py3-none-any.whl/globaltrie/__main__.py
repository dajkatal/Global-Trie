from .client_cli import main
main()