from .server_cli import main
main()